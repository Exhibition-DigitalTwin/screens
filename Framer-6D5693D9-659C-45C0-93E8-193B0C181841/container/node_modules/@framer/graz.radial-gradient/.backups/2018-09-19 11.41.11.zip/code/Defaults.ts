import { Data, animate, FramerFunction } from "framer"

const data = Data({ toggle: true, scale: 1, opacity: 1, rotation: 0, top: 0 })

export const Scale: FramerFunction = () => {
    return {
        scale: data.scale,
        onTap() {
            data.scale.set(0.6)
            animate.spring(data.scale, 1)
        },
    }
}

export const Rotate: FramerFunction = props => {
    data.rotation.set(props.rotation)

    return {
        rotation: data.rotation,
        onTap() {
            animate.spring(data.rotation, data.rotation.get() + 90, {
                tension: 250,
                friction: 20,
            })
        },
    }
}

export const Fade: FramerFunction = props => {
    data.opacity.set(props.opacity)

    return {
        opacity: data.opacity,
        onTap() {
            animate.linear(data.opacity, 0, 0.2)
        },
    }
}

export const SwitchOutput: FramerFunction = () => {
    return {
        opacity: data.opacity,
        rotation: data.rotation,
    }
}

export const SwitchInput: FramerFunction = () => {
    return {
        onTap() {
            const toggle = data.toggle.get()
            animate.spring(
                { opacity: data.opacity, rotation: data.rotation },
                {
                    opacity: toggle ? 0.5 : 1,
                    rotation: toggle ? 360 : 0,
                },
                { tension: 200, friction: 20 }
            )
            data.toggle.set(!toggle)
        },
    }
}
