import * as React from "react";
import { PropertyControls, ControlType } from "framer";

// Define type of property
interface Props {
    extent: string;
    shape: string;
    isFlipped: boolean;
    isRandom: boolean;
    xPos: number;
    yPos: number;
    amount: number;
}

export class Radial_gradient extends React.Component<Props> {


    randomColor() {
        return "#000000".replace(/0/g,function(){return (~~(Math.random()*16)).toString(16);});
    } 


    shuffle(a) {
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    }

    // Set default properties
    static defaultProps = {
        extent: 'farthest-corner',
        shape: 'ellipse',
        isFlipped: false,
        isRandomColor: false,
        color1: "#FBAD66",
        color2: "#F70103",
        color3: "#4E246F",
        color4: "#01369F",
        color5: "#2E53FA",
        amount: 3,
        xPos: 50,
        yPos: 50

    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
        // colorArray: { type: ControlType.String, title: "Colors" },
        shape: { 
            type: ControlType.Enum, 
            options: ['circle', 'ellipse'],
            title: "Shape" 
        },
        extent: {
            type: ControlType.Enum,
            options: ['closest-side', 'closest-corner', 'farthest-side', 'farthest-corner'],
            title: "Extent" 
        },
        isFlipped: { type: ControlType.Boolean, title: "Flip color" },
        isRandom: { type: ControlType.Boolean, title: "Random" },
        xPos: { 
            type: ControlType.Number, 
            title: "X" 
        },
        yPos: { 
            type: ControlType.Number, 
            title: "Y" 
        },

        amount: { type: ControlType.Number, min: 2, max: 5, title: "Colors" },
        color1: { type: ControlType.Color, title: "Color 1" },
        color2: { type: ControlType.Color, title: "Color 2" },
        color3: {
            type: ControlType.Color,
            title: "Color 3",
            hidden(props) {
                if (props.amount >= 3) {
                    return false;
                } else {
                    return true;
                }
            }
        },
        color4: {
            type: ControlType.Color,
            title: "Color 4",
            hidden(props) {
                if (props.amount >= 4) {
                    return false;
                } else {
                    return true;
                }
            }
        },
        color5: {
            type: ControlType.Color,
            title: "Color 5",
            hidden(props) {
                if (props.amount >= 5) {
                    return false;
                } else {
                    return true;
                }
            }
        }
    }


    private allColors = [];

    componentWillReceiveProps(props: Props) {
        this.allColors.length = 0;
        for (let i = 0; i < props.amount; i++) {            
            this.allColors.push(props[`color${i + 1}`]);
        }
    }

    componentWillMount() {
        for (let i = 0; i < this.props.amount; i++) {
            this.allColors.push(this.props[`color${i + 1}`]);
        }
    }


    render() {

        
        const { extent, isFlipped, shape, xPos, yPos, isRandom, amount } = this.props;


        if (isRandom) {
            //console.log(this.randomColor());
            for (let i = 0; i < amount; i++) {
                console.log( this.allColors.concat('bajs') );
                
                //console.log(this.randomColor());
            }
        }
 
        

        isFlipped ? this.allColors : this.allColors.reverse()
        isRandom ? this.shuffle(this.allColors) : this.allColors 

        

        const style: React.CSSProperties = {
            height: "100%",
            background: '-webkit-radial-gradient(' + xPos + '% ' + yPos + '%,' + shape + ' ' + extent + ', ' + this.allColors  + ')'
        };

        return <div style={style}></div>;
    }
}
